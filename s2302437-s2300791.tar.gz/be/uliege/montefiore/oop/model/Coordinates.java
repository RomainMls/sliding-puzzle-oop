package be.uliege.montefiore.oop.model;

public class Coordinates implements Cloneable{
   protected int xpos;
   protected int ypos;

   public Coordinates(int xpos, int ypos){
      this.xpos = xpos;
      this.ypos = ypos;
   }

   public int getX(){
      return xpos;
   }

   public int getY(){
      return ypos;
   }

   public void setX(int xpos){
      this.xpos = xpos;
   }

   public void setY(int ypos){
      this.ypos = ypos;
   }

   public Object clone(){
      Coordinates clone;
      try{
         clone = (Coordinates) super.clone();
      }
      catch(CloneNotSupportedException e){
         throw new InternalError("Unable to clone Coordinates");
      }
      return clone;
   }
}
